import React, { useState, useEffect } from "react";

/* Label with optional “*” */
export const Label = ({ htmlFor, children, required }) => (
  <label htmlFor={htmlFor} className="text-sm font-medium text-gray-700">
    {children}
    {required && <span className="text-red-500"> *</span>}
  </label>
);

/* Text / file input */
export const Input = React.memo(
  ({
    id,
    label,
    type = "text",
    required = false,
    error,
    value,
    onChange,
    inputRef,
    ...rest
  }) => (
    <div className="flex flex-col space-y-1">
      <Label htmlFor={id} required={required}>
        {label}
      </Label>
      <input
        id={id}
        name={id}
        type={type}
        ref={inputRef}
        value={type === "file" ? undefined : value || ""}
        onChange={onChange}
        required={required}
        accept={type === "file" ? "image/*" : undefined}
        className={`border rounded-xl px-4 py-3 w-full bg-white focus:ring-2 focus:ring-orange-400 focus:outline-none transition ${
          error ? "border-red-500" : "border-gray-300"
        }`}
        aria-invalid={!!error}
        {...rest}
      />
      {error && (
        <p id={`${id}-error`} className="text-sm text-red-500">
          {error}
        </p>
      )}
    </div>
  )
);

/* Select dropdown */
export const Select = React.memo(
  ({ id, label, required = false, error, value, onChange, children }) => (
    <div className="flex flex-col space-y-1">
      <Label htmlFor={id} required={required}>
        {label}
      </Label>
      <select
        id={id}
        name={id}
        value={value || ""}
        onChange={onChange}
        required={required}
        aria-invalid={!!error}
        className={`border rounded-xl px-4 py-3 w-full bg-white appearance-none focus:ring-2 focus:ring-orange-400 focus:outline-none transition ${
          error ? "border-red-500" : "border-gray-300"
        }`}
        style={{
          backgroundImage:
            "url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"%239CA3AF\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 9l-7 7-7-7\"/></svg>')",
          backgroundPosition: "right 0.5rem center",
          backgroundSize: "1.5em",
          backgroundRepeat: "no-repeat",
        }}
      >
        {children}
      </select>
      {error && (
        <p id={`${id}-error`} className="text-sm text-red-500">
          {error}
        </p>
      )}
    </div>
  )
);

/* Tiny preview for image/file inputs */
export const ImagePreview = React.memo(({ file, onRemove }) => {
  const [src, setSrc] = useState(null);

  useEffect(() => {
    if (file && !src) {
      const reader = new FileReader();
      reader.onloadend = () => setSrc(reader.result);
      reader.readAsDataURL(file);
    }
  }, [file, src]);

  if (!src) return null;
  return (
    <div className="relative w-32 h-32">
      <img
        src={src}
        alt="preview"
        className="object-cover w-full h-full rounded border"
      />
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="absolute top-0 right-0 bg-red-600 text-white rounded-full px-1"
        >
          ×
        </button>
      )}
    </div>
  );
});

/* Progress bar */
export const StepIndicator = ({ step, total }) => (
  <div className="text-center text-sm font-medium text-gray-600 mb-8">
    <div className="mb-2">
      Step {step} of {total}
    </div>
    <div className="w-full bg-gray-200 h-2 rounded-full">
      <div
        className="bg-orange-500 h-2 rounded-full transition-all"
        style={{ width: `${(step / total) * 100}%` }}
      />
    </div>
  </div>
);

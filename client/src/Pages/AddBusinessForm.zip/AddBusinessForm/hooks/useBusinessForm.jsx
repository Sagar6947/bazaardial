import { useState, useRef, useCallback, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../../../utils/api";
import { AuthContext } from "../../../context/AuthContext";

/* ── static option lists (unchanged) ────────────────────────── */
export const CATEGORY_OPTIONS = [
  "Civil Contractor",
  "Waterproofing Applicator",
  "Plumber",
  "Carpenter",
  "Painter",
  "Borewell Drilling",
  "Electrician",
  "Solar Panel Installer",
  "Real Estate",
  "Construction Material Suppliers",
];
export const EXPERIENCE_OPTIONS = [
  "0-1 year",
  "1-2 years",
  "2-5 years",
  "5-10 years",
  "10+ years",
];
export const LOCALITY_OPTIONS = [
  "Rau",
  "Silicon City",
  "Rajendra Nagar",
  "Choithram mandi",
  "Bhawarkua Square",
  "Navlakha Square",
  "Geeta Bhawan",
  "Palasia",
  "LIG Square",
  "Vijay Nagar",
  "Dewas Naka",
  "Mangaliya",
  "Mhow Naka",
  "Chandan Nagar",
  "Hawa Bangla",
  "Bada ganpati",
  "Mari Mata",
  "Kalani Nagar",
  "Gandhi Nagar",
  "Chota Bangarda",
  "Near Aurobindo",
  "MR 10",
  "Tejaji Nagar",
  "Musakhedi",
  "Bangali Square",
  "Khajrana Square",
];

/* ── constants ─────────────────────────────────────────────── */
const TOTAL_STEPS = 5;
const PHONE_RGX = /^\d{10}$/;
const ZIP_RGX = /^\d{6}$/;
const URL_RGX = /^https?:\/\/.+/i;
const GSTIN_RGX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

/* required fields for “Add” flow */
const REQUIRED_BY_STEP_ADD = {
  1: [
    "businessName",
    "category",
    "primaryPhone",
    "experience",
    "shortDesc",
    "fullDesc",
  ],
  2: ["aadhar"],
  3: [],
  4: ["street", "city", "state", "zipCode"],
  5: [
    "openingHourH",
    "openingHourM",
    "openingHourA",
    "closingHourH",
    "closingHourM",
    "closingHourA",
  ],
};

/* ── blank model ───────────────────────────────────────────── */
const INITIAL_DATA = {
  businessName: "",
  category: "",
  primaryPhone: "",
  secondaryPhone: "",
  experience: "",
  shortDesc: "",
  fullDesc: "",
  logo: null,
  banner: null,
  aadhar: null,
  gallery: [],

  websiteUrl: "",
  facebookUrl: "",
  whatsappUrl: "",
  instagramUrl: "",
  linkedinUrl: "",
  youtubeUrl: "",
  xUrl: "",

  street: "",
  landmark: "",
  locality: "",
  city: "Indore",
  state: "Madhya Pradesh",
  zipCode: "",

  registrationNumber: "",
  gstin: "",

  openingHourH: "",
  openingHourM: "",
  openingHourA: "AM",
  closingHourH: "",
  closingHourM: "",
  closingHourA: "PM",
};

/* split "14:30" → ["02","30","PM"] */
const from24h = (t = "") => {
  const [hh = "", mm = ""] = t.split(":");
  if (!hh) return ["", "", "AM"];
  const h = parseInt(hh, 10);
  const A = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return [String(h12).padStart(2, "0"), mm, A];
};

/* ───────────────────────────────────────────────────────────── */
export default function useBusinessForm(businessData = null) {
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);
  const isEditMode = !!businessData?._id;

  /* dynamic required-fields map */
  const REQUIRED = isEditMode
    ? { ...REQUIRED_BY_STEP_ADD, 2: [] } // aadhar not required when editing
    : REQUIRED_BY_STEP_ADD;

  /* pre-fill when editing */
  const [data, setData] = useState(() => {
    if (!isEditMode) return INITIAL_DATA;

    const [oH, oM, oA] = from24h(businessData.openingHour);
    const [cH, cM, cA] = from24h(businessData.closingHour);

    return {
      ...INITIAL_DATA,
      ...businessData,
      openingHourH: oH,
      openingHourM: oM,
      openingHourA: oA,
      closingHourH: cH,
      closingHourM: cM,
      closingHourA: cA,
      gallery: businessData.galleryUrls || [],
    };
  });

  /* ── local state ────────────────────────────────────────── */
  const [errors, setErrors] = useState({});
  const [alert, setAlert] = useState("");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(1);

  /* refs to hidden file inputs */
  const refs = {
    logo: useRef(),
    banner: useRef(),
    aadhar: useRef(),
    gallery: useRef(),
  };

  const to24h = (h, m, a) => {
    if (!h || !m || !a) return "";
    let hh = parseInt(h, 10) % 12;
    if (a === "PM") hh += 12;
    return `${hh.toString().padStart(2, "0")}:${m}`;
  };

  /* ── validation helpers ─────────────────────────────────── */
  const validateField = useCallback(
    (id, val) => {
      const v = typeof val === "string" ? val.trim() : val;

      if (REQUIRED[step]?.includes(id) && !v) return "Required";

      if (
        ["primaryPhone", "secondaryPhone"].includes(id) &&
        v &&
        !PHONE_RGX.test(v)
      )
        return "Enter 10-digit phone";

      if (id === "locality" && v && !LOCALITY_OPTIONS.includes(v))
        return "Pick locality";

      if (id === "zipCode" && v && !ZIP_RGX.test(v))
        return "PIN must be 6 digits";

      if (id === "gstin" && v && !GSTIN_RGX.test(v)) return "Invalid GSTIN";

      if (
        [
          "websiteUrl",
          "facebookUrl",
          "instagramUrl",
          "linkedinUrl",
          "youtubeUrl",
          "xUrl",
        ].includes(id) &&
        v &&
        !URL_RGX.test(v)
      )
        return "Invalid URL";

      if (id === "whatsappUrl" && v && !PHONE_RGX.test(v))
        return "Enter 10-digit number";

      if (id === "gallery" && v.length > 12) return "Max 12 images";

      return "";
    },
    [step, REQUIRED]
  );

  const validateStep = useCallback(() => {
    const errs = {};
    let ok = true;
    (REQUIRED[step] || []).forEach((f) => {
      const e = validateField(f, data[f]);
      if (e) {
        errs[f] = e;
        ok = false;
      }
    });
    setErrors((p) => ({ ...p, ...errs }));
    return ok;
  }, [step, data, validateField, REQUIRED]);

  /* ── onChange / removeGallery remain unchanged ──────────── */
  const onChange = (e) => {
    const { id, type, value, files } = e.target;
    setAlert("");

    if (type === "file") {
      if (id === "gallery") {
        const imgs = [...data.gallery, ...Array.from(files)].slice(0, 12);
        setData((d) => ({ ...d, gallery: imgs }));
        setErrors((p) => ({ ...p, gallery: validateField("gallery", imgs) }));
      } else {
        setData((d) => ({ ...d, [id]: files[0] }));
        setErrors((p) => ({ ...p, [id]: validateField(id, files[0]) }));
      }
      return;
    }

    const sanitized = ["primaryPhone", "secondaryPhone", "zipCode"].includes(id)
      ? value.replace(/\D/g, "")
      : id === "gstin"
      ? value.toUpperCase()
      : value;

    setData((d) => ({ ...d, [id]: sanitized }));
    setErrors((p) => ({ ...p, [id]: validateField(id, sanitized) }));
  };

  const removeGallery = (file) =>
    setData((d) => ({ ...d, gallery: d.gallery.filter((f) => f !== file) }));

  /* ── wizard nav (unchanged) ─────────────────────────────── */
  const next = () => {
    if (validateStep()) {
      setStep((s) => Math.min(s + 1, TOTAL_STEPS));
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };
  const prev = () => setStep((s) => Math.max(s - 1, 1));

  /* ── submit (POST vs PUT) ───────────────────────────────── */
  const submit = async (e) => {
    e.preventDefault();
    if (!validateStep()) {
      setAlert("Fix errors first");
      return;
    }

    setBusy(true);
    try {
      const fd = new FormData();
      const body = {
        ...data,
        openingHour: to24h(
          data.openingHourH,
          data.openingHourM,
          data.openingHourA
        ),
        closingHour: to24h(
          data.closingHourH,
          data.closingHourM,
          data.closingHourA
        ),
      };

      if (/^\d{10}$/.test(body.whatsappUrl))
        body.whatsappUrl = `https://wa.me/91${body.whatsappUrl}`;

      /* append scalars */
      Object.entries(body).forEach(([k, v]) => {
        if (
          [
            "gallery",
            "openingHourH",
            "openingHourM",
            "openingHourA",
            "closingHourH",
            "closingHourM",
            "closingHourA",
          ].includes(k)
        )
          return;
        if (v !== undefined && v !== null && v !== "") fd.append(k, v);
      });

      /* new/changed files only */
      const maybeFile = (k, val) => val instanceof File && fd.append(k, val);
      maybeFile("logo", data.logo);
      maybeFile("banner", data.banner);
      maybeFile("aadhar", data.aadhar);
      data.gallery
        .filter((g) => g instanceof File)
        .forEach((f) => fd.append("gallery", f));

      /* API */
      const res = isEditMode
        ? await api.put(`/business/${businessData._id}`, fd, {
            headers: { "Content-Type": "multipart/form-data" },
          })
        : await api.post("/business", fd, {
            headers: { "Content-Type": "multipart/form-data" },
          });

      const newTk = res.data.accessToken || res.data.token;
      if (newTk) login(newTk);

      alert(isEditMode ? "Business updated!" : "Business added!");
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setAlert(err.response?.data?.message || "Something went wrong");
      console.error(err);
    } finally {
      setBusy(false);
    }
  };

  /* ── exposed API ─────────────────────────────────────────── */
  return {
    data,
    errors,
    alert,
    busy,
    step,
    TOTAL_STEPS,
    refs,
    onChange,
    removeGallery,
    next,
    prev,
    submit,
  };
}

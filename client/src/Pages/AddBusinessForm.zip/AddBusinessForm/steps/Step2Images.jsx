import { Input, ImagePreview } from "../ui/FormAtoms";

export default function Step2Images({
  data,
  errors,
  onChange,
  removeGallery,
  refs,
}) {
  return (
    <div className="grid gap-6">
      <div className="grid sm:grid-cols-2 gap-6">
        {/* Logo */}
        <div>
          <Input
            id="logo"
            label="Logo"
            type="file"
            inputRef={refs.logo}
            onChange={onChange}
            error={errors.logo}
          />
          {data.logo && (
            <ImagePreview
              file={data.logo}
              onRemove={() => {
                refs.logo.current.value = "";
                onChange({ target: { id: "logo", type: "file", files: [] } });
              }}
            />
          )}
        </div>

        {/* Banner */}
        <div>
          <Input
            id="banner"
            label="Banner"
            type="file"
            inputRef={refs.banner}
            onChange={onChange}
            error={errors.banner}
          />
          {data.banner && (
            <ImagePreview
              file={data.banner}
              onRemove={() => {
                refs.banner.current.value = "";
                onChange({ target: { id: "banner", type: "file", files: [] } });
              }}
            />
          )}
        </div>

        {/* Aadhar */}
        <div>
          <Input
            id="aadhar"
            label="Aadhar"
            type="file"
            required
            inputRef={refs.aadhar}
            onChange={onChange}
            error={errors.aadhar}
          />
          {data.aadhar && (
            <ImagePreview
              file={data.aadhar}
              onRemove={() => {
                refs.aadhar.current.value = "";
                onChange({ target: { id: "aadhar", type: "file", files: [] } });
              }}
            />
          )}
        </div>
      </div>

      {/* Gallery */}
      <div>
        <Input
          id="gallery"
          label="Gallery (max 12, ≤5 MB each)"
          type="file"
          multiple
          inputRef={refs.gallery}
          onChange={onChange}
          error={errors.gallery}
        />
        <div className="flex flex-wrap gap-3 mt-3">
          {data.gallery.map((img) => (
            <ImagePreview
              key={img.name + img.size} // use something stable
              file={img}
              onRemove={() => removeGallery(img)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
